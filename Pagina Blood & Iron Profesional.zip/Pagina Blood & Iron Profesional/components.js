// c:\Users\ADRI-KI\Documents\MARKO - UTP Y PROGRAMACION\PAGINAS CREADAS-EN PROCESO\otra pagina de blood & iron\components.js
document.addEventListener("DOMContentLoaded", function() {
    const path = window.ROOT_PATH || '.';

    const navbarHTML = `
    <nav class="border-b border-zinc-800 bg-zinc-950/95 sticky top-0 z-50 backdrop-blur">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-20 items-center">
                <!-- Logo -->
                <a href="${path}/index.html" class="flex-shrink-0 flex items-center gap-2 cursor-pointer group">
                    <i data-lucide="dumbbell" class="h-8 w-8 text-red-600 group-hover:rotate-12 transition-transform duration-300"></i>
                    <span class="brand-font text-2xl font-bold tracking-wider text-white">BLOOD <span class="text-red-600">&</span> IRON</span>
                </a>
                <!-- Menu Desktop -->
                <div class="hidden md:flex space-x-8 items-center">
                    <a href="${path}/index.html" class="brand-font text-zinc-400 hover:text-white hover:border-b-2 hover:border-red-600 transition-all uppercase tracking-wide text-sm py-1">Inicio</a>
                    <a href="${path}/rutinas.html" class="brand-font text-zinc-400 hover:text-white hover:border-b-2 hover:border-red-600 transition-all uppercase tracking-wide text-sm py-1">Rutinas</a>
                    
                    <!-- Dropdown Group -->
                    <div class="relative group">
                        <button class="brand-font text-zinc-400 hover:text-white hover:border-b-2 hover:border-red-600 transition-all uppercase tracking-wide text-sm py-1 flex items-center gap-1 focus:outline-none">
                            Laboratorio Digital <i data-lucide="chevron-down" class="w-4 h-4"></i>
                        </button>
                        <!-- Dropdown Menu -->
                        <div class="absolute left-0 mt-0 w-64 bg-zinc-900 border border-zinc-800 shadow-xl rounded-sm hidden group-hover:block pt-2 z-50">
                            <div class="py-1">
                                <a href="${path}/laboratorio-digital/calculadora.html" class="block px-4 py-3 text-sm text-zinc-300 hover:bg-zinc-800 hover:text-red-500 transition brand-font uppercase tracking-wide">Calculadora de Frecuencia</a>
                                <a href="${path}/laboratorio-digital/nutricion.html" class="block px-4 py-3 text-sm text-zinc-300 hover:bg-zinc-800 hover:text-red-500 transition brand-font uppercase tracking-wide">Nutrición Heavy Duty</a>
                                <a href="${path}/laboratorio-digital/selector.html" class="block px-4 py-3 text-sm text-zinc-300 hover:bg-zinc-800 hover:text-red-500 transition brand-font uppercase tracking-wide">Selector de Rutinas</a>
                            </div>
                        </div>
                    </div>

                    <a href="${path}/articulos.html" class="brand-font text-zinc-400 hover:text-white hover:border-b-2 hover:border-red-600 transition-all uppercase tracking-wide text-sm py-1">Artículos</a>
                    <a href="${path}/filosofia.html" class="brand-font text-zinc-400 hover:text-white hover:border-b-2 hover:border-red-600 transition-all uppercase tracking-wide text-sm py-1">Filosofía</a>
                    <a href="#newsletter" class="brand-font text-white bg-red-700 hover:bg-red-800 px-4 py-1 rounded-sm transition uppercase tracking-wide text-sm font-bold flex items-center gap-2">
                        Suscribirse <i data-lucide="chevron-right" class="w-4 h-4"></i>
                    </a>
                </div>
                <!-- Mobile Menu Button -->
                <button id="mobile-menu-btn" class="md:hidden text-zinc-400 hover:text-white transition focus:outline-none">
                    <i data-lucide="menu" class="w-8 h-8"></i>
                </button>
            </div>
        </div>

        <!-- Mobile Menu Dropdown (Hidden by default) -->
        <div id="mobile-menu" class="hidden md:hidden bg-zinc-950 border-b border-zinc-800 absolute w-full left-0 top-20 shadow-xl shadow-black/50">
            <div class="px-4 py-6 space-y-4 flex flex-col">
                <a href="${path}/index.html" class="brand-font text-zinc-400 hover:text-white hover:pl-2 transition-all uppercase tracking-wide text-lg font-bold">Inicio</a>
                <a href="${path}/rutinas.html" class="brand-font text-zinc-400 hover:text-white hover:pl-2 transition-all uppercase tracking-wide text-lg font-bold">Rutinas</a>
                
                <!-- Mobile Submenu -->
                <div class="pl-4 border-l-2 border-zinc-800 space-y-2">
                    <span class="brand-font text-zinc-500 uppercase tracking-wide text-xs font-bold block">Laboratorio Digital</span>
                    <a href="${path}/laboratorio-digital/calculadora.html" class="brand-font text-zinc-400 hover:text-white hover:pl-2 transition-all uppercase tracking-wide text-lg font-bold block">Calculadora</a>
                    <a href="${path}/laboratorio-digital/nutricion.html" class="brand-font text-zinc-400 hover:text-white hover:pl-2 transition-all uppercase tracking-wide text-lg font-bold block">Nutrición</a>
                    <a href="${path}/laboratorio-digital/selector.html" class="brand-font text-zinc-400 hover:text-white hover:pl-2 transition-all uppercase tracking-wide text-lg font-bold block">Selector</a>
                </div>

                <a href="${path}/articulos.html" class="brand-font text-zinc-400 hover:text-white hover:pl-2 transition-all uppercase tracking-wide text-lg font-bold">Artículos</a>
                <a href="${path}/filosofia.html" class="brand-font text-zinc-400 hover:text-white hover:pl-2 transition-all uppercase tracking-wide text-lg font-bold">Filosofía</a>
                <a href="#newsletter" class="brand-font text-white bg-red-700 hover:bg-red-800 px-4 py-3 rounded-sm transition uppercase tracking-wide text-sm font-bold text-center flex items-center justify-center gap-2">
                    Suscribirse <i data-lucide="chevron-right" class="w-4 h-4"></i>
                </a>
            </div>
        </div>
    </nav>
    `;

    const navContainer = document.getElementById('navbar-container');
    if (navContainer) {
        navContainer.innerHTML = navbarHTML;
        
        // Lógica del Menú Móvil
        const mobileBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        
        if (mobileBtn && mobileMenu) {
            mobileBtn.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
            });
        }
    }

    const footerHTML = `
    <footer class="border-t border-zinc-800 bg-zinc-950 py-10 mt-auto">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <div class="flex justify-center items-center gap-2 mb-4 opacity-50">
                <i data-lucide="dumbbell" class="h-6 w-6 text-zinc-500"></i>
                <span class="brand-font text-lg font-bold text-zinc-500">BLOOD & IRON</span>
            </div>
            <p class="text-zinc-600 text-sm">
                &copy; 2024 Blood & Iron Philosophy. Todos los derechos reservados.
            </p>
        </div>
    </footer>
    `;

    const footerContainer = document.getElementById('footer-container');
    if (footerContainer) {
        footerContainer.innerHTML = footerHTML;
    }

    // Re-inicializar iconos Lucide para el contenido inyectado
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
});
