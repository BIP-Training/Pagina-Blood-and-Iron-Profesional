// c:\Users\ADRI-KI\Documents\MARKO - UTP Y PROGRAMACION\PAGINAS CREADAS-EN PROCESO\otra pagina de blood & iron\app.js

// Esperar a que el DOM esté completamente cargado (opcional si el script está al final, pero buena práctica)
document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Inicializar Iconos Lucide
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    } else {
        console.error("Lucide icons failed to load.");
    }

    // 2. Lógica del Menú Móvil
    const menuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');

    // Solo añadimos el evento si los elementos existen en la página actual
    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });

        // Mejora: Cerrar el menú automáticamente al hacer clic en un enlace
        const menuLinks = mobileMenu.querySelectorAll('a');
        menuLinks.forEach(link => {
            link.addEventListener('click', () => {
                mobileMenu.classList.add('hidden');
            });
        });
    }

    // --- Lógica de Calculadora de Frecuencia (calculadora.html) ---
    const ageInput = document.getElementById('age');
    const ageDisplay = document.getElementById('age-display');
    const calcBtn = document.getElementById('calculate-btn');
    const resultContainer = document.getElementById('result-container');
    const daysResult = document.getElementById('days-result');
    const messageResult = document.getElementById('message-result');

    // Actualizar display de edad
    if (ageInput && ageDisplay) {
        ageInput.addEventListener('input', (e) => {
            ageDisplay.textContent = `${e.target.value} Años`;
        });
    }

    if (calcBtn && document.getElementById('recovery-form')) { // Check if we are on calculator page
        calcBtn.addEventListener('click', () => {
            // 1. Obtener Valores
            const age = parseInt(document.getElementById('age').value);
            const intensity = document.querySelector('input[name="intensity"]:checked').value;
            const stress = document.querySelector('input[name="stress"]:checked').value;

            // 2. Lógica del Algoritmo
            let days = 2; // Base fisiológica mínima (48h)

            // Factor Edad
            if (age > 50) days += 2;
            else if (age > 30) days += 1;

            // Factor Intensidad
            if (intensity === 'heavyduty') days += 2;
            else if (intensity === 'failure') days += 1;

            // Factor Estrés
            if (stress === 'high') days += 1;

            // 3. Mostrar Resultado con Animación
            resultContainer.classList.remove('hidden');
            // Pequeño delay para permitir que la transición CSS funcione
            setTimeout(() => {
                resultContainer.classList.remove('opacity-0', 'translate-y-4');
            }, 50);

            daysResult.textContent = `${days} DÍAS`;
            
            // Mensaje Dinámico
            if (days <= 3) {
                messageResult.textContent = "Frecuencia Alta. Apto para rutina PPL o Full Body.";
                messageResult.className = "text-xl text-green-500 font-serif italic border-t border-zinc-900 pt-6";
                daysResult.className = "text-7xl md:text-9xl font-bold text-white brand-font mb-6 leading-none";
            } else if (days <= 5) {
                messageResult.textContent = "Frecuencia Heavy Duty Ideal. Usa rutina dividida.";
                messageResult.className = "text-xl text-yellow-500 font-serif italic border-t border-zinc-900 pt-6";
                daysResult.className = "text-7xl md:text-9xl font-bold text-white brand-font mb-6 leading-none";
            } else {
                messageResult.textContent = "Zona de Peligro. Prioriza recuperación total o reduce volumen.";
                messageResult.className = "text-xl text-red-500 font-serif italic border-t border-zinc-900 pt-6";
                daysResult.className = "text-7xl md:text-9xl font-bold text-red-600 brand-font mb-6 leading-none animate-pulse";
            }
        });
    }

    // --- Lógica de Nutrición (nutricion.html) ---
    const calcBtnNutri = document.getElementById('calculate-btn'); // Reusing ID, check context
    const initialState = document.getElementById('initial-state');
    const resultsContent = document.getElementById('results-content');
    
    const totalEl = document.getElementById('total-calories');
    const carbsEl = document.getElementById('carbs-val');
    const proteinEl = document.getElementById('protein-val');
    const fatEl = document.getElementById('fat-val');

    if (calcBtnNutri && document.getElementById('macro-form')) { // Check if we are on nutrition page
        calcBtnNutri.addEventListener('click', () => {
            // 1. Get Values
            const weightInput = document.getElementById('weight');
            const weight = parseFloat(weightInput.value);
            
            if (!weight || isNaN(weight) || weight <= 0) {
                alert("Por favor ingresa un peso corporal válido.");
                weightInput.focus();
                return;
            }

            const activity = parseFloat(document.querySelector('input[name="activity"]:checked').value);
            const goal = parseFloat(document.querySelector('input[name="goal"]:checked').value);

            // 2. Calculations
            // TMB (Tasa Metabólica Basal) = Peso en kg * 22
            const bmr = weight * 22;
            
            // TDEE (Gasto Total) = TMB * Factor Actividad
            const tdee = bmr * activity;
            
            // Total Calories Adjusted by Goal
            const totalCalories = Math.round(tdee + goal);

            // Macros (Grams)
            // Carbs (60%) - 4 kcal/g
            const carbsGrams = Math.round((totalCalories * 0.60) / 4);
            
            // Protein (25%) - 4 kcal/g
            const proteinGrams = Math.round((totalCalories * 0.25) / 4);
            
            // Fat (15%) - 9 kcal/g
            const fatGrams = Math.round((totalCalories * 0.15) / 9);

            // 3. Display Results
            initialState.classList.add('hidden');
            resultsContent.classList.remove('hidden');
            
            // Animate numbers (simple implementation)
            totalEl.textContent = totalCalories;
            carbsEl.textContent = `${carbsGrams}g`;
            proteinEl.textContent = `${proteinGrams}g`;
            fatEl.textContent = `${fatGrams}g`;
        });
    }

    // --- Lógica de Selector de Rutinas (selector.html) ---
    const generateBtn = document.getElementById('generate-btn');
    const resultZone = document.getElementById('result-zone');
    const protocolName = document.getElementById('protocol-name');
    const protocolDesc = document.getElementById('protocol-desc');
    const protocolLink = document.getElementById('protocol-link');

    if (generateBtn && document.getElementById('strategy-form')) {
        generateBtn.addEventListener('click', () => {
            // 1. Obtener valores
            const expEl = document.querySelector('input[name="experience"]:checked');
            const freqEl = document.querySelector('input[name="frequency"]:checked');

            if (!expEl || !freqEl) {
                alert("Por favor selecciona todas las opciones para generar tu estrategia.");
                return;
            }

            const exp = expEl.value;
            const freq = freqEl.value;

            // 2. Lógica de Selección
            let result = {};

            if (exp === 'novice') {
                // CASO 1: Novato (Cualquier frecuencia)
                result = {
                    name: "CONSOLIDACIÓN (Full Body)",
                    desc: "Tu prioridad es construir una base neurológica y estructural. La frecuencia alta con volumen bajo es ideal para aprender patrones motores.",
                    link: "rutinas.html#fullbody"
                };
            } else if (exp === 'intermediate') {
                if (freq === 'high') { // 4 días
                    // CASO 3: Intermedio + 4 días
                    result = {
                        name: "PUSH-PULL-LEGS (Rotativo)",
                        desc: "La división lógica por excelencia. Permite entrenar con mayor volumen por grupo muscular sin solapamiento excesivo.",
                        link: "rutinas.html#ppl"
                    };
                } else { // 2-3 días
                    // CASO 2: Intermedio + Baja/Std frecuencia
                    result = {
                        name: "ARNOLD SPLIT (Adaptado)",
                        desc: "Enfoque en grupos antagonistas para maximizar el flujo sanguíneo y la recuperación local con días de descanso completos.",
                        link: "rutinas.html#arnold"
                    };
                }
            } else if (exp === 'advanced') {
                if (freq === 'high') { // 4 días
                    // CASO 4: Avanzado + 4 días
                    result = {
                        name: "DORIAN YATES SPLIT (Blood & Guts)",
                        desc: "Volumen mínimo, intensidad suicida. Una división de 4 días diseñada para destruir el músculo y dejarlo descansar 7 días completos.",
                        link: "rutinas.html#ppl" 
                    };
                } else { // Menos de 4 días
                    // CASO 5: Avanzado + Baja frecuencia
                    result = {
                        name: "HEAVY DUTY IDEAL",
                        desc: "La máxima expresión de la intensidad. Frecuencia ultra-baja para permitir la recuperación sistémica de esfuerzos máximos.",
                        link: "rutinas.html#arnold"
                    };
                }
            }

            // 3. Mostrar Resultado
            protocolName.textContent = result.name;
            protocolDesc.textContent = result.desc;
            protocolLink.href = result.link;

            resultZone.classList.remove('hidden');
            // Scroll suave hacia el resultado
            resultZone.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
    }
});
